# celcodec

CLIP STUDIO PAINTのファイルを読み取り、素材を復元し、レイヤー・タイムライン・音声を編集して保存する非公式TypeScriptライブラリです。CELSYSによる公式ライブラリではありません。

ESM / Node.js 24以降。解析・編集にDOMは不要です。SQLite、WASM、Canvas、フォント、Workerは利用側で用意します。0.7.1は文書セッションAPIと文書・フレーム・選択構成の領域描画を提供する、`private: true` のローカル開発パッケージです。CLIP・画像・採取データは配布しません。0.2.0からの変更は[移行手順](docs/migration-0.3.md)、0.6.0のテンプレート変更は[新規文書の準備](docs/document-templates.md)を参照してください。

機能ごとの読み取り・保持・描画・編集保存と、CSPで確認した範囲は[互換性の対応表](docs/compatibility.md)にまとめています。描画できることと、その設定を安全に書き換えられることは別の契約です。

## 文書を読み取る

```ts
import initSqlJs from 'sql.js'
import { openDocument } from 'celcodec'

const SQL = await initSqlJs()
const session = openDocument(SQL, clipBytes)
try {
  const { canvas, layers, timelines } = session.document
  // layers / children は上から順。ビューは読み取り専用。
  const layer = layers.find((layer) => !layer.folder)
  if (layer) {
    const result = await session.decodeLayer(layer.id, { source: 'prefer-original' })
    // pixels は非乗算RGBA8。left / top は文書上のピクセル位置。
    // diagnostics で近似・欠落・未対応を確認する。
  }
  const firstTimeline = timelines[0]
  if (firstTimeline) {
    const timeline = session.readTimeline(firstTimeline.id)
    // セルキーは再生開始からの相対値。負数や範囲外のキーも保持する。
  }
} finally {
  session.dispose()
}
```

画像は必要なレイヤーだけを復元します。音声・動画を静止画へ自動変換しません。音声は `session.readAudio(layerId, timelineId)` で抽出でき、同じ文書の索引を再利用します。バイナリの調査には `document.binaries` と `session.copyBinary(handle)` を使います。

大判文書の疎なラスター・マスク・保存済み合成画像は、キャンバス面積ではなく復元範囲の予算で読み出せます。0.4.0では`imageLimits`で画像予算を指定し、全面復元・描画・編集時の固定上限も置き換えられます。`openLayerRaster`／`createRasterSource`、`compositeLayerTiles`、`encodePngRows`で領域単位の復元・合成・PNG出力も可能です。[容量の目安・使い方・実測と制限](docs/image-resources.md)を参照してください。

`celcodec/render`の`createDocumentRenderer(session, { canvas })`は、用紙色・レイヤー配置・素材変形・効果・マスク・階層合成を解釈して描画します。`render({ region })`で文書座標の領域を、`renderTiles()`でタイルを取得できます。`layerId`を指定すると一つのレイヤー／フォルダーを復元できます。`createFrameRenderer`にも`region`と`renderTiles(frame, options)`があり、2Dカメラやキーフレームの適用切り替えと組み合わせられます。アプリ側でCLIPの座標や効果を再実装する必要はありません。[上位描画APIとPNG出力](docs/document-rendering.md)を参照してください。

プロパティのキーは `session.readKeyframes(trackId)`、マスク・ベタ塗り・用紙・効果のメタデータは `session.readLayerProperties(layerId)`、3Dのカメラ・オブジェクト情報と未解析sceneは `session.read3DLayer(layerId)` で取得できます。これらの解析には画像の展開が不要です。[キーフレームの評価範囲](docs/keyframes.md)と[機能別の対応・実測結果](docs/native-layer-research.md)を参照してください。

## タイムラインを評価する

複数タイムラインの名前・FPS・開始／終了・長さ・保存された選択先とラベルを読み取れます。基本設定に加え、タイムラインの複製・削除・並べ替え、クリップの移動・トリム・延長・分割・条件付き結合、フレーム挿入・削除を編集保存できます。セル指定は変形・不透明度と同居するクリップも対象にでき、既存の数値プロパティキーには追加・移動・削除と補間・傾き編集を提供します。入力原点は `frameOrigin` で再生開始／絶対0を選べます。音声・動画の素材参照は `readMediaSources(layerId)` で調べられます。[時間の単位・FPS変換](docs/timelines.md)と[組み立て・キー編集・CSP検証・制限](docs/timeline-authoring.md)を参照してください。

タイムラインの再生には `session.createPlayback(timelineId)` を使います。返却された評価器の `evaluate(frame, { camera: 'document', layerKeyframes: 'document' })` が、保存された表示設定に従い、セル指定、可視性、不透明度、親階層と入れ子の2Dカメラを含む変形を返します。各設定を `'apply'` / `'ignore'` にすると、文書を変更せず適用を切り替えられます。一定値・線形・滑らかな補間と左右独立のカーブハンドルに対応し、未知の方式や必要な保存値が欠ける区間は診断付きの未解決値にします。使い終えた評価器は `dispose()` で解放します。画像まで得るには `celcodec/render` の `createFrameRenderer(session, timelineId, { canvas })` を使い、`await renderer.render(frame, { camera, layerKeyframes })` を呼びます。保存設定に従う描画、両設定の一時切り替え、元画像とマスクの復元・変形・合成を接続します。近似診断を返し、表示内容が未解決なら画像を返しません。[フレーム描画API](docs/frame-rendering.md)を参照してください。[再生API・CSP比較・制限](docs/playback.md)を参照してください。

レイヤーごとの上書き、保存値と実際の適用状態の取得、`setCameraDisplay` / `setLayerKeyframesEnabled` による明示的な保存変更は、[表示設定と再生方針](docs/animation-display.md)を参照してください。既存コードとの互換性のため、オプション省略時のカメラは従来どおり `'apply'` です。

## 編集して保存する

```ts
const session = openDocument(SQL, clipBytes)
try {
  const plan = await session.planEdits([
    { type: 'renameLayer', layerId: selectedId, name: '新しい名前' },
    { type: 'setLayerAttributes', layerId: selectedId, attributes: { visible: true } },
  ])
  if (!plan.allowed) {
    console.log(plan.diagnostics)
  } else {
    // impact に更新する行・外部blob数・キャッシュの影響範囲が入る。
    const { bytes } = await session.save(plan)
    // 利用側で保存先を選び、bytesを書き出す。
  }
} finally {
  session.dispose()
}
```

変更対象を操作として指定します。削除は `removeLayer`、移動は `moveLayer`、セル割り当ては `setCelKeys`、ラベルは `setTrackLabel`、音声は `replaceAudio` です。操作の制約は[編集契約](docs/architecture.md)に記載しています。

新規・複製トラックには `{ timelineId, layerId }` で同じ計画内から操作できます。空トラックの復元、独立セルクリップの挿入・削除、複数タイムラインの音声、参照方針を明示したセル移動に対応します。出力内枠は `canvas.animationFrame`、ライトテーブル参照は `layer.role` で区別できます。[文書組み立ての契約](docs/document-assembly.md)を参照してください。

空の操作リストによる保存は、編集用DBを開かず入力と同一のバイト列を返します。未知のデータは原データと参照を保持できる場合に編集し、保持条件を確認できない操作は診断付きで拒否します。3D以外の対応編集後も既存3Dのsceneと参照を保持する回帰テストと、CSPでの保存・再オープンを追加しています。[3D保持の検証範囲](docs/native-layer-research.md#3d以外を編集した後の保持検証)を参照してください。

セッションは開いた文書の不変なスナップショットです。保存は計画を一度だけ消費し、セッションのビューを変更しません。続きを編集する場合は、返却されたbytesを新しいセッションで開いてください。未使用の計画は `discardPlan(plan)` で解放できます。

基準フレーム・作画フレーム・余白・演出フレームは `canvas.animationPaper` で読み取り、`setAnimationPaper` で保存します。`resizeCanvas` で対応構成のキャンバスを拡張し、`replaceRasterPixels` でUUIDやセル指定を維持した画像差し替えができます。保存済みフォルダー／動画プレビューも取得できます。[座標・設定・対応条件](docs/animation-paper.md)を参照してください。

## 新規文書

```ts
import { readFile } from 'node:fs/promises'
import { createDocument } from 'celcodec'
// 利用側がCSPで作成した空のアニメーション文書。ファイルは同梱しません。
const seed = new Uint8Array(await readFile('my-empty-animation.clip'))
const session = await createDocument(SQL, seed, {
  width: 640,
  height: 480,
  dpi: 72,
  basisWidth: 640,
  basisHeight: 480,
  offsetX: 0,
  offsetY: 0,
})
// addLayer / createTimeline などを planEdits(operations, { seed }) へ渡す。
```

空テンプレートの階層・透明画素・必要なトラック構造を実行時に検査して、新規構造の生成に利用します。固定のファイルハッシュには依存しません。[テンプレートの条件](docs/document-templates.md)に従って利用側で用意してください。レイヤーの追加・タイムラインの新規作成・音声編集には `{ seed }` を渡します。既存レイヤーの名称・属性変更には不要です。画像の配置は `left` / `top` で明示し、キャンバス外は切り詰めます。

## 素材とCanvas

`celcodec/material` はOffscreen属性とタイルbodyからの `decodeRaster`、ベクター、文字、ブラシなどの素材APIを提供します。`celcodec/canvas` の `createCanvasRenderer(factory)` にはCanvas生成を注入できます。返却Canvasの所有権を引き渡す場合は `detach(canvas)`、作業終了時は `dispose()` を呼びます。工程分離・出力命名は利用側の責務です。

`celcodec/render` の `compositeLayers` は画素・マスク・階層を受け取り、28種類の合成モード、フォルダの通過、クリッピングを処理します。Canvasなしで利用でき、入力を変更しません。CSP採取画像に基づく近似であり、診断を返します。[合成API・検証範囲](docs/compositing.md)を参照してください。

色調補正レイヤーは7種類の設定を読み取り、合成画像へ適用できます。単独のRGBA配列には `celcodec/render` の `applyAdjustment` を使います。マスク・不透明度・クリッピングも合成時に適用します。カラーバランスとグラデーションマップは未対応です。[色調補正の対応範囲](docs/adjustments.md)を参照してください。

元画像・保存画像の選択、マスク、配置、近似の扱いは復元結果と診断で確認できます。全ブラシ・全効果の再現、3Dの内部編集、未知トラックの内部編集には対応していません。

基本丸ペンの細線・輪郭・筆圧カーブ・線端はCSPの独立出力と比較して改善しています。制御点に保存された筆先間隔と乱数の継続状態も読み取ります。対応条件と残る誤差は[ベクターブラシの検証記録](docs/vector-brushes.md)を参照してください。

存在する0バイトのベクターデータは、空の素材として近似警告なしで復元します。データの欠落・破損や、透明な筆跡とは区別します。[空ベクターと診断の契約](docs/vector-material-diagnostics.md)に判定条件と検証範囲を記載しています。

## 診断と資源

`ClipError.diagnostic` は安定した `code` / `kind` / `severity` と構造化データを持ちます。画面用文言は利用側で定義します。Workerでは `serializeClipError` / `deserializeClipError` を使えます。資源上限とキャンセルは処理を停止します。

入力は既定でコピーして所有します。`{ ownership: 'borrow' }` は、解放まで入力を変更しない接続向けです。返却された画像・音声・保存bytesは利用側の所有です。セッションの `dispose()` は進行中の復元を停止し、保持している入力・索引・編集計画を解放します。

`AbortSignal` に対応します。同期SQL処理を別スレッドから即時中断したい場合は、利用側でWorkerを終了します。読み取り・書き込み・素材復元の上限はそれぞれ異なります。同じセッションの画像復元は同時に1件、保持する編集計画も1件です。

## ローカル開発

```sh
npm ci --ignore-scripts
npm run dev:setup -- --public
npm run verify:public
```

`verify:public` は非公開資料なしで、整形・lint・TypeScript 7/6・公開API・公開単体テスト・build・pack監査・独立Node consumerを検証します。資料庫を設定した開発環境では `npm run verify:local` でCSP採取値との回帰・ブラウザWorker・性能検査まで実行します。資料不足は失敗として扱い、テストを黙ってスキップしません。[開発・検証ガイド](docs/development.md)と[公開境界・Git運用](docs/publication.md)を参照してください。CSP実機の開閉・別名保存は別の検証です。これらのコマンドは公開・pushを行いません。

[設計と保持条件](docs/architecture.md) / [0.3.0への移行](docs/migration-0.3.md) / [0.3.0検証記録](docs/verification-0.3.md) / [出典とMITライセンス](THIRD_PARTY_NOTICES.md)

描画時だけ階層・表示・不透明度を組み替える場合は、[描画構成API](docs/render-composition.md)を使います。利用アプリとの共同改修は[連携開発](docs/linked-development.md)を参照してください。
