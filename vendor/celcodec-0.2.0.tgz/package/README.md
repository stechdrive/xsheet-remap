# celcodec

CLIP STUDIO PAINTのファイルを読み取り、素材を復元し、レイヤー・タイムライン・音声を編集して保存する非公式TypeScriptライブラリです。CELSYSによる公式ライブラリではありません。

ESM / Node.js 24以降。解析にはDOMを必要とせず、SQLiteの初期化、WASMのURL、Canvas、フォント、Workerは利用側で用意します。現在は `private: true` のローカル開発パッケージです。

## CLIPを読み取る

```ts
import initSqlJs from 'sql.js'
import { openDocument } from 'celcodec/read'

const SQL = await initSqlJs() // ブラウザでは利用側でWASMの場所を指定
const session = openDocument(SQL, clipBytes)
try {
  const { width, height, layers, timelines } = session.document
  // layersは上から順。attributesには不透明度・可視性・合成モードなどの保存値が入ります。
  const layer = layers.find(layer => !layer.isFolder)
  if (layer) {
    const result = await session.decodeLayer(layer.id)
    // result.layer.pixels: 非乗算RGBA8と文書上のleft/top
    // result.diagnostics: 欠落、未対応、近似、資源上限の理由
  }
} finally {
  session.dispose()
}
```

子レイヤーは `children` にあります。素材は必要になった時に復元します。音声・動画の素材は静止画として自動生成しません。音声抽出には `readClipAudio` を使います。生のタイムライン、ラベル、外部blobは表示範囲への丸めとは別に保持します。

## 編集して保存する

```ts
import { readFile, writeFile } from 'node:fs/promises'
import { readEditableDocument } from 'celcodec/read'
import { writeClip } from 'celcodec/write'

const seedBytes = new Uint8Array(await readFile(new URL(import.meta.resolve('celcodec/blank.clip'))))
const opened = await readEditableDocument(SQL, clipBytes, 'input.clip')
const nodes = opened.layers.map(node =>
  node.id === selectedId ? { ...node, name: '新しい名前' } : node)
const result = await writeClip(SQL, seedBytes, {
  plan: {
    namespace: 'my-tool:document-id',
    rootName: 'Artwork',
    folders: [],
    timelines: [],
    document: { nodes, canvas: opened.canvas, source: clipBytes },
  },
  canvas: opened.canvas,
  fit: 'crop',
  images: {},
})
await writeFile('edited.clip', result.bytes)
```

全レイヤーを編集状態に渡してください。省略した既存レイヤーは削除対象です。タイムラインの空配列は既存トラックを保持します。無編集保存は入力と同じバイト列を返し、元の入力は変更しません。新規生成では `document` を省略し、`folders` と `timelines` を指定します。

読み取れたCLIPがすべて安全に書き換えられるとは限りません。未対応トリガーや安全に再構築できないタイムラインは診断付きで拒否します。保存条件・対応範囲は [設計と制限](docs/extraction.md) を参照してください。

## 単一素材とCanvas

`celcodec/material` はOffscreen属性＋タイルbodyを受け取る `decodeRaster`、`decodeVectorStrokes`、`renderVectorMaterial`、テーブルからブラシ・文字・マスク等を解決する `createMaterialDecoder` を公開します。

```ts
import { decodeRaster } from 'celcodec/material'
const { pixels, diagnostics } = await decodeRaster(attributeBytes, tileBytes, {
  crop: true, mask: false,
})
```

マスクには `mask: true` を指定します。`defaultColor` は切り詰め領域外のマスク値です。`crop` の既定値は `false`。有効な空画像は透明な1ピクセル、画像データの欠落は未定義の `pixels` として区別します。

`celcodec/canvas` は `createCanvasRenderer((width, height) => canvas)` にCanvas生成を注入できます。返却Canvasを利用側へ引き渡す場合は `detach(canvas)`、処理の終了時は `dispose()` を呼びます。レイヤーカラー、縁取り、水彩境界、反転・閾値の効果は画素APIでも使えます。階層合成や工程別の出力方針は含みません。

## 診断と実行環境

`ClipError.diagnostic` と戻り値の `diagnostics` は安定した `code` / `kind` / `severity` を持ちます。画面文言は利用側で用意してください。ベクター・文字・水彩境界には近似があり、全ブラシ・全効果との完全一致を保証しません。

実行時依存は `fflate`。SQL/WASMは同梱しません。ラスター展開は標準 `DecompressionStream` / `Blob` を使用し、`inflate(bytes, limit, signal)` を差し替え可能です。入力bytes、テーブル、ブラシ画像は借用中に変更しないでください。

読み取りと書き込みには異なる上限があります。`AbortSignal` を各操作へ渡せますが、同期処理中の外部キャンセルは利用側のWorker終了などで制御してください。Canvasの返却画像や文書全体の累積メモリは利用側でも管理します。

## ローカル開発

```sh
npm ci --ignore-scripts
npm test
npm run typecheck
npm run build
npm run check:package
```

`check:package` はtarballを監査し、別の利用側ディレクトリへoffline installして全公開入口・DOMなしの型定義を検証します。配布内容は許可リストで限定し、検査済みの空seedだけを含みます。

[アプリとの接続](docs/adapters.md) / [検証記録](docs/verification.md) / [出典とMITライセンス](THIRD_PARTY_NOTICES.md)
